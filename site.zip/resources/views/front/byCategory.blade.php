@extends('layouts.master_ar')


@section('content')
@include('front.showArticle')
@endsection