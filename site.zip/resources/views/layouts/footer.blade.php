<div class="container">
<div class="row">

<div class="col-12 col-md-12">
<div class="footer-single-widget">
<ul class="footer-menu d-flex justify-content-between" dir="{{$tdir}}" align="{{$talign}}">
<li><a href="/">{{ __("Home")}}</a></li>
<li><a href="{{asset('page/1')}}">{{ __("Writer")}}</a></li>
<li><a href="{{asset('category/3')}}">{{ __("News") }}</a></li>
<li><a href="{{asset('category/4')}}">{{ __("Activities") }}</a></li>
<li><a href="{{asset('category/5')}}">{{ __("Articles") }}</a></li>
<li><a href="{{asset('category/6')}}">{{ __("Studies") }}</a></li>
<li><a href="{{asset('category/7')}}">{{ __("Novels") }}</a></li>
<li><a href="{{asset('category/8')}}">{{ __("Short Stories") }}</a></li>
<li><a href="{{asset('page/2')}}">{{ __("Palestinian days")}}</a></li>
<li><a href="{{asset('page/3')}}">{{ __("Beit Daras")}}</a></li>
<li><a href="{{asset('page/4')}}">{{ __("Friendly sites")}}</a></li>
<li><a href="{{asset('category/9')}}">{{ __("Photos") }}</a></li>
<li><a href="{{asset('category/10')}}">{{ __("Vedio") }}</a></li>
<li><a href="{{asset('page/4')}}">{{ __("Friendly sites")}}</a></li>
<li><a href="{{asset('page/5')}}">{{ __("Contact Us")}}</a></li>

</ul>
</div>
</div>
<div class="col-12 col-md-12">
<div class="footer-single-widget">
<h5>{{ __("All Rights Reserved")}}</h5>
</div>
</div>
</div>
</div>