<?php $__env->startSection('title', 'إدارة المقالات'); ?>

<?php $__env->startSection('content'); ?>

<div class="panel panel-default">

	<div class="panel-heading">
     
<form method="get" action="<?php echo e(asset('admin/articles')); ?>" class="row">
        <div class="col-sm-3">
        <input autofocus name="key" id="key" type="text" required="required" class="form-control" placeholder="ابحث ...">
      	</div>
            
      	<div class="col-sm-1">
         <button class="btn btn-primary" type="submit">إبحث!</button>
        </div>
        
        <div class="col-sm-8 text-left">
            <a class="btn btn-success" href="<?php echo e(asset('admin/articles/create')); ?>">
            <i class="glyphicon glyphicon-plus"></i>
            اضافة مقال جديد
        </a>
        </div>
    </form>    
    
    </div>
    <!-- / .panel-heading -->
    
    
    <div class="panel-body">
	
<?php if(isset($key)): ?>    
<h3>البحث عن / <?php echo e($key); ?></h3><br />
<?php endif; ?>
 
<div class="table-responsive">    
<table class="table table-striped table-bordered table-hover">
<thead>
<tr>
<th width="5%">#</th>
<th>العنوان</th>
<th width="12%">القسم</th>
<th width="10%">الصورة</th>
<th width="7%">فعال</th>
<th width="5%"></th>
<th width="5%"></th>
</tr>
</thead>
<tbody>
<?php $i = 1; ?>
<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td><?php echo e($i++); ?></td>
<td><b><?php echo e($result->title_ar); ?><br><?php echo e($result->title_en); ?></b></td>
<td><?php echo e($result->category->name_ar); ?></td>
<td><img class="thumbnail" style="max-height:100px; max-width:100px;" 
src="<?php echo e(asset('storage/img/'.$result->image )); ?>"></td>
<td>
 
<input type="checkbox" value="<?php echo e($result->id); ?>" class="cbActive" <?php echo e($result->is_active?"checked":""); ?> >
</td>


<td>
	<a href="<?php echo e(asset('admin/articles/'.$result->id.'/edit')); ?>" class="btn btn-primary">
    <span class="glyphicon glyphicon-edit"></span></a>  
</td>


<td>    
	<a href="<?php echo e(asset('admin/articles/delete/'.$result->id)); ?>" class="btn Confirm btn-danger">
	<span class="glyphicon glyphicon-trash"></span></a>
</td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($results->links()); ?>


</div>
<!-- / .table-responisve -->
    

    </div>
    <!-- / panel-body -->

</div>

<script>
    $(function(){
        $(".cbActive").click(function(){
            var id=$(this).val();
            $.get("/admin/articles/active/"+id);
        });
    });
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>