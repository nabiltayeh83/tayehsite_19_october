<?php $__env->startSection('title', 'تعديل تصنيف'); ?>


<?php $__env->startSection('content'); ?>

<div class="panel panel-default">


<div class="panel-body">
	
<?php echo Form::open(['route' => ['categories.update', $results->id], 'method' => 'POST', 'files' => 'true', 
'class' => 'form-horizontal']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>




<div class="form-group">
<?php echo e(Form::label('title_itm', 'التصنيف بالعربي', ['class' => 'col-sm-2'])); ?>

<div class="col-sm-10">
<?php echo e(Form::text('name_ar', $results->name_ar, ['class' => 'form-control'])); ?>

</div></div>


<div class="form-group">
<?php echo e(Form::label('title_itm', 'التصنيف بالإنجليزي', ['class' => 'col-sm-2'])); ?>

<div class="col-sm-10">
<?php echo e(Form::text('name_en', $results->name_en, ['class' => 'form-control', 'style' => 'direction:ltr;'])); ?>

</div></div>


<div class="form-group">
<?php echo e(Form::label('is_active', 'فعال', ['class' => 'col-sm-2'])); ?>

<div class="col-sm-10">
<?php echo e(Form::checkbox('is_active', 1, 1, ['id' => 'is_active'])); ?>

</div></div>



<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<?php echo e(Form::submit('حفظ', ['class' => 'btn btn-primary'])); ?>

<a href="<?php echo e(asset('admin/categories/')); ?>" class="btn btn-default">إلغاء</a>
</div></div>


<?php echo Form::close(); ?>

 

</div>
<!-- / panel-body -->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>