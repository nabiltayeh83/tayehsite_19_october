<div class="container">
<div class="row">

<div class="col-12 col-md-12">
<div class="footer-single-widget">
<ul class="footer-menu d-flex justify-content-between" dir="<?php echo e($tdir); ?>" align="<?php echo e($talign); ?>">
<li><a href="/"><?php echo e(__("Home")); ?></a></li>
<li><a href="<?php echo e(asset('page/1')); ?>"><?php echo e(__("Writer")); ?></a></li>
<li><a href="<?php echo e(asset('category/3')); ?>"><?php echo e(__("News")); ?></a></li>
<li><a href="<?php echo e(asset('category/4')); ?>"><?php echo e(__("Activities")); ?></a></li>
<li><a href="<?php echo e(asset('category/5')); ?>"><?php echo e(__("Articles")); ?></a></li>
<li><a href="<?php echo e(asset('category/6')); ?>"><?php echo e(__("Studies")); ?></a></li>
<li><a href="<?php echo e(asset('category/7')); ?>"><?php echo e(__("Novels")); ?></a></li>
<li><a href="<?php echo e(asset('category/8')); ?>"><?php echo e(__("Short Stories")); ?></a></li>
<li><a href="<?php echo e(asset('page/2')); ?>"><?php echo e(__("Palestinian days")); ?></a></li>
<li><a href="<?php echo e(asset('page/3')); ?>"><?php echo e(__("Beit Daras")); ?></a></li>
<li><a href="<?php echo e(asset('page/4')); ?>"><?php echo e(__("Friendly sites")); ?></a></li>
<li><a href="<?php echo e(asset('category/9')); ?>"><?php echo e(__("Photos")); ?></a></li>
<li><a href="<?php echo e(asset('category/10')); ?>"><?php echo e(__("Vedio")); ?></a></li>
<li><a href="<?php echo e(asset('page/4')); ?>"><?php echo e(__("Friendly sites")); ?></a></li>
<li><a href="<?php echo e(asset('page/5')); ?>"><?php echo e(__("Contact Us")); ?></a></li>

</ul>
</div>
</div>
<div class="col-12 col-md-12">
<div class="footer-single-widget">
<h5><?php echo e(__("All Rights Reserved")); ?></h5>
</div>
</div>
</div>
</div>