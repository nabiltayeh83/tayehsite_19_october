<?php $__env->startSection("content"); ?>
<div class="row">

	<div class="col-md-8">
    	<form method="post" enctype="multipart/form-data" 
        action="<?php echo e(asset('admin/users/permission/'.$id)); ?> " 
        class="form-horizontal">
			<?php echo e(csrf_field()); ?>

            <?php
            $links = \DB::table("links")->where("parent_id",0)->get();            
            ?>
            <ul class="permissions list-unstyled">
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $sublinks = \DB::table("links")->where("parent_id",$l->id)->get();
                
                $hasPermission=\DB::table("roles")->where("link_id",$l->id)
                    ->where("user_id",$id)->count();
                ?>
                <li>
                    <label>
                        <input <?php echo e($hasPermission?"checked":""); ?> type="checkbox" name="permissions[]" value="<?php echo e($l->id); ?>" >
                        <b><?php echo e($l->title); ?></b>
                    </label>
                    <ul class="list-unstyled">
                         <?php $__currentLoopData = $sublinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $hasSubPermission=\DB::table("roles")->where("link_id",$sl->id)
                    ->where("user_id",$id)->count();
                        ?>
                        <li>
                            <label style="padding-right:20px; margin-bottom:10px;">
                                
                             <input <?php echo e($hasSubPermission?"checked":""); ?>  type="checkbox" name="permissions[]" 
                             value="<?php echo e($sl->id); ?>" >
                             <?php echo e($sl->title); ?>

                            </label>
                        </li>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
              <button type="submit" class="btn btn-primary">حفظ</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection("js"); ?>
<script>
    $(function(){
        $(".permissions :checkbox").click(function(){
            var checked=$(this).prop("checked");
            $(this).parent().next().find(":checkbox").prop("checked",checked);
            
            $(this).parents("ul").each(function(){
                checked=$(this).find(":checked").size()>0;
                $(this).prev().find(":checkbox").prop("checked",checked);
            });
        });
    });
</script> 
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>