<div class="hero-post-area">
<div class="container">
<div class="row">
<div class="col-12">
<div class="hero-post-slide">

<?php $i = 1; ?>                                                       
<?php $__currentLoopData = $marquee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$title = $item->{"title".$lg};
?>	
<?php if(isset($title)): ?>	
<div class="single-slide d-flex align-items-center">
<div class="post-number"><p><?php echo e($i++); ?></p></div>
<div class="post-title">
<a href="<?php echo e(asset('details/'. $item->id)); ?>"><?php echo e($title); ?></a>
</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
</div>
</div>
</div>
</div>
</div>