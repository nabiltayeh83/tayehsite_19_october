<div class="sidebar-widget-area">
<a href="<?php echo e(asset('category/3')); ?>"><h5 class="title"><?php echo e(__("News")); ?></h5></a>
<div class="widget-content">

<?php $i = 1; ?>
                                                       
<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$title = $item->{"title".$lg};
?>	
<?php if(isset($title)): ?>
<div class="single-blog-post post-style-2 d-flex align-items-center widget-post">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$item->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<h5 class="mb-0"><?php echo e($title); ?></h5>
</a>
</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

</div>
</div>
                        
                        

<div class="sidebar-widget-area">
<h5 class="title"><?php echo e(__("Stay Connected")); ?></h5>
<div class="widget-content">
<div class="social-area d-flex justify-content-between">
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-twitter"></i></a>
<a href="#"><i class="fa fa-pinterest"></i></a>
<a href="#"><i class="fa fa-vimeo"></i></a>
<a href="#"><i class="fa fa-instagram"></i></a>
<a href="#"><i class="fa fa-google"></i></a>
</div>
</div>
</div>
                                                


<div class="sidebar-widget-area">
<a href="<?php echo e(asset('category/5')); ?>"><h5 class="title"><?php echo e(__("Articles")); ?></h5></a>
<div class="widget-content">

<?php $i = 1; ?>
                                                       
<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$title = $item->{"title".$lg};
?>	
<?php if(isset($title)): ?>

<div class="single-blog-post todays-pick">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$item->image)); ?>" alt=""></a>
</div>
<div class="post-content px-0 pb-0">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5>
</a>
</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</div>
</div>



<div class="sidebar-widget-area">
<a href="<?php echo e(asset('category/7')); ?>"><h5 class="title"><?php echo e(__("Novels")); ?></h5></a>
<div class="widget-content">
                                                       
<?php $__currentLoopData = $novels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$lg = "_" . Session::get('locale');
?>	
<?php if(isset($title)): ?>

<div class="single-blog-post todays-pick">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$item->image)); ?>" alt=""></a>
</div>
<div class="post-content px-0 pb-0">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5>
</a>
</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</div>
</div>



<div class="sidebar-widget-area">
<a href="<?php echo e(asset('category/6')); ?>"><h5 class="title"><?php echo e(__("Studies")); ?></h5></a>
<div class="widget-content">
                                                       
<?php $__currentLoopData = $studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$lg = "_" . Session::get('locale');
?>	
<?php if(isset($title)): ?>

<div class="single-blog-post todays-pick">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$item->image)); ?>" alt=""></a>
</div>
<div class="post-content px-0 pb-0">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5>
</a>
</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</div>
</div>