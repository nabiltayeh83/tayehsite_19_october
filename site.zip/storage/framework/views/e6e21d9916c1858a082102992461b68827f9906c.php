<?php $__env->startSection('content'); ?>
<h1>Add Article</h1>

<?php echo Form::open(); ?>


<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_ar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>