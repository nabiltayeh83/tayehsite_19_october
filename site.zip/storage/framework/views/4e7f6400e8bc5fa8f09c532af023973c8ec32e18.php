<?php $__env->startSection('title', 'إدارة الصفحات'); ?>



<?php $__env->startSection('content'); ?>

<div class="panel panel-default">


    <!-- / .panel-heading -->
    
    
    <div class="panel-body">

 
<div class="table-responsive">    
<table class="table table-striped table-bordered table-hover">
<thead>
<tr>
<th width="7%">#</th>
<th>الصفحة بالعربي</th>
<th>الصفحة بالإنجليزي</th>
<th width="12%">الصورة</th>
<th width="8%">فعال</th>
<th width="8%"></th>
</tr>
</thead>
<tbody>
<?php $i = 1; ?>
<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td><?php echo e($i++); ?></td>
<td><b><?php echo e($result->title_ar); ?></td>
<td><b><?php echo e($result->title_en); ?></td>
<td>


<?php
  if($result->image){
?>

<img class="thumbnail" style="max-height:100px; max-width:100px;" 
src="<?php echo e(asset('storage/img/'.$result->image )); ?>">

<?php
  }
?>

</td>
<td>
<input type="checkbox" value="<?php echo e($result->id); ?>" class="cbActive" <?php echo e($result->is_active?"checked":""); ?> >
</td>



<td>
	<a href="<?php echo e(asset('admin/pages/'.$result->id.'/edit')); ?>" class="btn btn-primary">
    <span class="glyphicon glyphicon-edit"></span></a>  
</td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

</div>
<!-- / .table-responisve -->
    

    </div>
    <!-- / panel-body -->

</div>

<script>
    $(function(){
        $(".cbActive").click(function(){
            var id=$(this).val();
            $.get("/admin/pages/active/"+id);
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>