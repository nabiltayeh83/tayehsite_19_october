<?php $__env->startSection('title', 'تعديل مستخدم'); ?>

<?php $__env->startSection('content'); ?>

<div class="panel panel-default">


<div class="panel-body">
	
<?php echo Form::open(['route' => ['users.update', $result->id], 'method' => 'POST', 'files' => 'true', 'class' => 
'form-horizontal']); ?>

<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>



<div class="form-group">
<label for="title" class="col-sm-2 control-label">الاسم</label>
<div class="col-sm-10">
<?php echo e(Form::text('name', $result->name, ['class' => 'form-control', 'placeholder' => 'الاسم', 'required' => 'required'])); ?>

</div>
</div>



<div class="form-group">
<label for="title" class="col-sm-2 control-label">البريد الإلكتروني</label>
<div class="col-sm-10"><b><?php echo e($result->email); ?></b></div>
</div>



<div class="form-group">
<label for="title" class="col-sm-2 control-label">كلمة المرور</label>
<div class="col-sm-10">
<input  type="text" class="form-control" name="password1" id="password1" placeholder="اضف لاعادة  كلمة المرور ">
</div>
</div>






<div class="form-group">
<label for="is_active" class="col-sm-2 control-label">فعال</label>
<div class="col-sm-10">
	<?php echo e(Form::checkbox('is_active', 1, '', ['id' => 'is_active', $result->is_active?"checked":""])); ?>

</div>
</div>


<div class="form-group">
<div class="col-sm-offset-2 col-sm-10">
<?php echo e(Form::submit('تعديل', ['class' => 'btn btn-primary'])); ?>

<a href="<?php echo e(asset('admin/users')); ?>" class="btn btn-default">إلغاء</a>
</div>
</div>




<?php echo Form::close(); ?>

 

</div>
<!-- / panel-body -->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>