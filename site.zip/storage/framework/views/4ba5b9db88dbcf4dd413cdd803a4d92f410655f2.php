<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('admin/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('front-theme/fonts/cairo/cairo.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('admin/sb-admin-2.css')); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('admin/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">

</head>

<body style="font-family:cairo;">

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(asset('admin/articles')); ?>">لوحة التحكم</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-left">
                <!-- /.dropdown -->
                
<?php if(auth()->guard()->guest()): ?>
	<?php else: ?>
	<li class="dropdown">
    <!-- Auth::user()->role_id -->
	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true" v-pre>
	<i class="glyphicon glyphicon-user"></i> <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
	</a>
    
	<ul class="dropdown-menu" style="font-size:12px;">
    
    <li style="padding:5px;">
		<a href="<?php echo e(asset('admin/users/changepassword')); ?>">
		<i class="glyphicon glyphicon-lock"></i> تغيير كلمة المرور</a>
	</li>  
    
    <li style="padding:5px;">
	<a href="<?php echo e(route('logout')); ?>"
	onclick="event.preventDefault();
	document.getElementById('logout-form').submit();">
	<i class="glyphicon glyphicon-log-out"></i> تسجيل خروج</a>

	<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
	<?php echo e(csrf_field()); ?>

	</form>
	</li>
    
	</ul>
	</li>
<?php endif; ?>
               
                
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->



   <?php if(auth()->guard()->guest()): ?>
   <?php else: ?>
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
       
         <?php             
         $links = DB::table('links')
                  ->join('roles', 'links.id', '=', 'roles.link_id')
                  ->where('links.parent_id', '=', 0)
                  ->where('links.showinmenu', '=', 1)
                  ->where('roles.user_id', '=', auth::user()->id)
                  ->get();     
         ?> 
                                     
		<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
        
            	<li>
                 <a href="<?php echo e(asset($link->url)); ?>" style="background:#999; color:#FFF; font-size:16px;">
                 <i class="glyphicon <?php echo e($link->icon); ?>"></i> <?php echo e($link->title); ?><span class="fa arrow"></span></a>
                 <ul class="nav nav-second-level">
                 
                  <?php             
                  $sublinks = DB::table('links')
                  ->join('roles', 'links.id', '=', 'roles.link_id')
                  ->where('links.parent_id', '=', $link->link_id)
                  ->where('links.showinmenu', '=', 1)
                  ->where('roles.user_id', '=', auth::user()->id)
                  ->get();     
                 ?> 
                 
                 <?php $__currentLoopData = $sublinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sublink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                 <li>
                    <a href="<?php echo e(asset($sublink->url)); ?>"><i class="glyphicon <?php echo e($sublink->icon); ?>"></i> <?php echo e($sublink->title); ?></a>
                 </li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    
                  </ul>
                 </li>
                       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
          
                           
                                
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
   <?php endif; ?>         
       
            
            
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
			<div class="row">
				<div class="col-lg-12">
					<h1 class="page-header"><?php echo $__env->yieldContent('title'); ?></h1>
				</div>
				<!-- /.col-lg-12 -->
			</div>
			<!-- /.row -->
			
            <?php echo $__env->make('layouts.error_msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            
            
			<!-- /.row -->
		</div>
	</div>
        <!-- /#page-wrapper -->

    <!-- /#wrapper -->

    <!-- jQuery Version 1.11.0 -->
    <script src="<?php echo e(asset('admin/jquery-1.11.0.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('admin/bootstrap.min.js')); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('admin/metisMenu.min.js')); ?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(asset('admin/sb-admin-2.js')); ?>"></script>
 
</body></html>
