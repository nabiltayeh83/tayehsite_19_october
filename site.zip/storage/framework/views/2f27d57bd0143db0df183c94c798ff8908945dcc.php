<?php
if($lg == '_en'){ $talign = "left"; $tdir = "ltr"; $langbutton = "عربي"; $lang = "ar"; }
else{ $talign = "right"; $tdir = "rtl"; $langbutton = "English"; $lang = "en"; }
?>


<!DOCTYPE html>
<html lang="<?php echo e($lang); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(__("Novelist Abdullah Tayeh")); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link href="<?php echo e(asset('front-theme/fonts/cairo/cairo.css')); ?>" rel="stylesheet">
</head>

<body style="font-family:cairo;">
    
<?php echo $__env->make('layouts.headernav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="hero-area">
 <div class="hero-slides owl-carousel">
   <div class="single-hero-slide bg-img background-overlay" style="background-image: 
   url(<?php echo e(asset('img/blog-img/bg2.jpeg')); ?>);"></div>
   <div class="single-hero-slide bg-img background-overlay" style="background-image: 
   url(<?php echo e(asset('img/blog-img/bg1.jpeg')); ?>);"></div>
 </div>       
<?php echo $__env->make('layouts.marquee', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


<div class="main-content-wrapper section-padding-100">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12 col-lg-8" dir="<?php echo e($tdir); ?>" align="<?php echo e($talign); ?>">
      <?php echo $__env->yieldContent('content'); ?>
      </div>
      
      <div class="col-12 col-md-8 col-lg-4">
        <div class="post-sidebar-area wow fadeInUpBig" data-wow-delay="0.2s" dir="<?php echo e($tdir); ?>" 
        align="<?php echo e($talign); ?>">
        <?php echo $__env->make('layouts.rightside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>
    </div>


</div>
</div>

<footer class="footer-area"><?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></footer>

    <script src="<?php echo e(asset('js/jquery/jquery-2.2.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('js/active.js')); ?>"></script>

</body></html>