<?php $__env->startSection('content'); ?>


<div class="post-content-area mb-50">

<div class="world-catagory-area">
<ul class="nav nav-tabs" id="myTab" role="tablist">
<a href="<?php echo e(asset('category/4')); ?>"><li class="title"><?php echo e(__("Activities")); ?></li></a>                                   
</ul>

<div class="tab-content" id="myTabContent">

<div class="tab-pane fade show active" id="world-tab-1" role="tabpanel" aria-labelledby="tab1">
<div class="row">

<div class="col-12 col-md-6">
<?php if($activities[0]): ?>
<div class=" wow fadeInUpBig" data-wow-delay="0.1s">
<?php
$title = $activities[0]->{"title".$lg};
?>	
<div class="single-blog-post">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $activities[0]->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$activities[0]->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $activities[0]->id)); ?>" class="headline"><h5><?php echo e($title); ?></h5></a>
</div>
</div>
</div>
<?php endif; ?>
</div>


<div class="col-12 col-md-6">
<?php for($i=1; $i<=4; $i++): ?> 
<?php
$title = $activities[$i]->{"title".$lg};
?>                                 
<?php if(isset($title)): ?>                                                 
<div class="single-blog-post post-style-2 d-flex align-items-center wow fadeInUpBig" data-wow-delay="0.5s">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $activities[$i]->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$activities[$i]->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $activities[$i]->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5></a>
</div>
</div>
<?php endif; ?>
<?php endfor; ?>
                                            
</div>

</div>
</div>
</div>
</div>




<div class="world-catagory-area mt-50">
<ul class="nav nav-tabs" id="myTab2" role="tablist">
<a href="<?php echo e(asset('category/9')); ?>"><li class="title"><?php echo e(__("Photos")); ?></li></a>
</ul>

<div class="tab-content" id="myTabContent2">

<div class="tab-pane fade show active" id="world-tab-10" role="tabpanel" aria-labelledby="tab10">
<div class="row">

<?php for($i=0; $i<=1; $i++): ?>
<?php
$title = $photos[$i]->{"title".$lg};
?>
<?php if(isset($title)): ?>
<div class="col-12 col-md-6">
<div class="single-blog-post wow fadeInUpBig" data-wow-delay="0.2s">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $photos[$i]->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$photos[$i]->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $photos[$i]->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5></a>
</div>
</div>
</div>
<?php endif; ?>
<?php endfor; ?>


<div class="col-12">

<div data-wow-delay="0.4s">
<div class="single-cata-slide">
<div class="row">
                                                        
<?php for($i=2; $i<=5; $i++): ?>
<?php
$title = $photos[$i]->{"title".$lg};
?>
<?php if(isset($title)): ?>
<div class="col-12 col-md-6">
<div class="single-blog-post post-style-2 d-flex align-items-center mb-1">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $photos[$i]->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$photos[$i]->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $photos[$i]->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5></a>
</div></div></div>
<?php endif; ?>
<?php endfor; ?>

</div>
</div>                               

</div>
</div>
</div>
</div>
                                
</div>
</div>


<div class="world-catagory-area mt-50">
<div class="title">
<a href="<?php echo e(asset('category/8')); ?>"><h5><?php echo e(__("Short Stories")); ?></h5></a>
</div>

<?php $__currentLoopData = $shortstories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$title = $item->{"title".$lg};
?>	
<?php if(isset($title)): ?>

<div class="single-blog-post post-style-4 d-flex align-items-center wow fadeInUpBig" data-wow-delay="0.5s">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $item->id)); ?>">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$item->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $item->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5>
</a>
</div>
</div>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>




<div class="world-catagory-area mt-50">
<ul class="nav nav-tabs" id="myTab2" role="tablist">
<a href="<?php echo e(asset('category/10')); ?>"><li class="title"><?php echo e(__("Vedio")); ?></li></a>
</ul>

<div class="tab-content" id="myTabContent2">

<div class="tab-pane fade show active" id="world-tab-10" role="tabpanel" aria-labelledby="tab10">
<div class="row">

<?php for($i=0; $i<=1; $i++): ?>
<?php
$title = $vedio[$i]->{"title".$lg};
$title = $vedio[$i]->{"title".$lg};
?>
<?php if(isset($title)): ?>
<div class="col-12 col-md-6">
<div class="single-blog-post wow fadeInUpBig" data-wow-delay="0.2s">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $vedio[$i]->id)); ?>" class="headline">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$vedio[$i]->image)); ?>" alt=""></a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $vedio[$i]->id)); ?>" class="headline">
<h5><?php echo e($title); ?></h5></a>
</div>
</div>
</div>
<?php endif; ?>
<?php endfor; ?>

</div>
</div>
                                
</div>
</div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_ar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>