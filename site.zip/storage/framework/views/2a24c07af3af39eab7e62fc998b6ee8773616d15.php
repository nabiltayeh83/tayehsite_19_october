<?php
if($lg == '_en'){ $talign = "left"; $tdir = "ltr"; }
else{ $talign = "right"; $tdir = "rtl";}
?>

<div class="row">
<div class="col-lg-12 text-right sidebar-widget-area"> 
<h5 class="title" dir="<?php echo e($tdir); ?>" align="<?php echo e($talign); ?>"> <?php echo e(__("Home")); ?> /  
<?php if(Route::currentRouteName() != 'homepage'): ?>


<?php
echo $category->{"name".$lg};
?>

<?php endif; ?>
</h5>
</div>
                    
<?php if(isset($results)): ?>
<div class="tab-pane fade show active" id="world-tab-1" role="tabpanel" aria-labelledby="tab1">

<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 	

<?php
$title = $r->{"title".$lg};
?>

<div class="single-blog-post post-style-4 d-flex align-items-center">
<div class="post-thumbnail">
<a href="<?php echo e(asset('details/'. $r->id)); ?>">
<img src="<?php echo e(asset('storage/img/thumbnail/'.$r->image)); ?>" alt="">
</a>
</div>
<div class="post-content">
<a href="<?php echo e(asset('details/'. $r->id)); ?>" class="headline">
<h5 id="h3title"><b><?php echo e($title); ?></b></h5>
</a>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  			
</div>
<?php endif; ?>		
   
<div class="col-lg-12 text-right">
<?php echo e($results->links()); ?>

</div>
   
</div>			
           